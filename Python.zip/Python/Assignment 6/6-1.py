str=input("Enter a String: ")
print("Reversed String :", str[::-1])