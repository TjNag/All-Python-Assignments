circle = {'radius': '', 'circumference': ''}

radius = float(input("Enter a radius : "))

circle['radius']=radius
circle['circumference']=2*3.14*radius

print(circle)