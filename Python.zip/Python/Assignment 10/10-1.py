dictionary = {}

a = ["ID", "Name", "Salary"]
b = ["001", "ABC", "15000"]

dictionary = dict(zip(a, b))

print(dictionary)