def OddEven(n):
    if(n%2 == 0):   
        print("Even")
    else:
        print("Odd")
n=int(input("Enter any number: "))
OddEven(n)