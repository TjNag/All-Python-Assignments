r= float(input("Enter radius of a circle: ")) 
l= float(input("Enter length of a rectangle: "))
b= float(input("Enter breadth of a reactangle: "))
ac= (22/7)*(r**2)
ar= l*b
print("Area of a circle= ", ac)
print("Area of a Rectangle= ",ar)
