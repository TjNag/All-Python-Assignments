ch= input("Enter a text: ")
if ch.isalpha():
    print("Alphabet")
elif ch.isnumeric():
    print("Numeric")
else:
    print("Special Character")
