a=input("Enter any number : ")
print(a[0])
