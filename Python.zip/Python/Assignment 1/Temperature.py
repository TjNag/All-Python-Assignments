c=float(input("Enter the temperature in Celcius: "))
f=(c*9/5)+32
print("Fahrenheit: ",f)
f=float(input("Enter the temperature in Fahrenheit : "))
c=(f-32)*5/9
print("Celcius: ",c)
