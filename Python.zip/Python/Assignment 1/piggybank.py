t=(10*10)+(5*5)+(15*2)+(20*1)
print("Total Amount of Money in Piggybank: ",t)
