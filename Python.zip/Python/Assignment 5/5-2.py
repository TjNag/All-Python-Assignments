mini = lambda a, b : min(a,b)
print(mini(5, 8))