str = 'B. Tech\nCSE\n4th Sem'

#split string by single space
chunks = str.split("\n")

print(chunks)