name=input("Enter name: ")
pan=input("Enter PAN: ")
print((name.isalpha() and pan.isalnum()))