res=lambda a,b:a+b
print("Addition =",res(2,4))