str=input("Enter a String: ")
for i in str:
    print(chr(ord(i)+3), end='')