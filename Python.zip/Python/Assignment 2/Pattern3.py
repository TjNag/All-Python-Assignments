'''
1           1
22          12
333         123
4444        1234
'''

for i in range(1,5):
    for j in range(1,i+1):
        print(i, end='')
    print()






#i=1;i<=4;i++
#j=1;j<=i;j++