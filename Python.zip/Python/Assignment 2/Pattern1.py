''' *               1
    **              12
    ***             123
    ****            1234   '''

for i in range(1,5):
    for j in range(1,i+1):
        print('*', end='')
    print()
    







'''  i=1;i<=4;i++
    j=1;j<=i;j++
    print(*)'''