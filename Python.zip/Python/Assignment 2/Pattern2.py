'''
****        4321
***         432
**          43
*           4
'''

for i in range(1,5,1):
    for j in range(4,i-1,-1):
        print('*', end='')
    print()







#i=1;i<=4;i=i+1
#j=4;j>=i;j=j-1