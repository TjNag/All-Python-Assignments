n=int(input("Enter any number: "))
s=0
for i in range(1,n+1):
    s=s+i
print("Sum: ",s)
