lt = input("Enter list elements : ").split()

print("List before reversing :", lt)

lt = lt[::-1]

print("List after reversing :", lt)