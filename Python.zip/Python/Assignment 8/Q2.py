lt = [1, 2, 3, 4, 5, 6, 7]

element=0
length = 0

for element in lt:
    length += 1

print("Length of list", lt, "=", length)