lt1 = input("Enter list elements : ").split()
lt2=[]
for i in lt1:
    lt2.append(i)

print("Copied list is : ", lt2)