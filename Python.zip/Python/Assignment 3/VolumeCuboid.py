l=float(input("Enter length of Cuboid : "))
b=float(input("Enter breadth of Cuboid : "))
h=float(input("Enter height of Cuboid : "))
vol = l*b*h
print("Volume :",vol)