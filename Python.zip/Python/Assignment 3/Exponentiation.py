a = int(input("Enter base : "))
b = int(input("Enter power : "))
print("Exponentiation of",a,"and",b,"=",a**b)