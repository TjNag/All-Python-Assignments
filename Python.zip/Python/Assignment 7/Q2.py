#Write a Python program to print absolute value, square root and cube of a number using math module.

import math

print(abs(-40))
print(math.sqrt(400))
print(math.pow(-4,3))