#Write a Python program that defines a function Armstrong in a module which will be used to find whether a number is armstrong or not and called from code in another module.

import Armstrong

n=int(input("Enter a number : "))

Armstrong.Armstrong(n)