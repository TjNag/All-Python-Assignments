def sort(a, b, c):
    if (a<=b and b<=c) or (a>=b and b>=c):
        return True
    else:
        return False
